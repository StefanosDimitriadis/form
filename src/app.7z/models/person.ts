export class Person {

    constructor(public id: number, public fullName: string, public name: string, public surname: string,
        public fatherName: string, public motherName?: string,
        public position?: string, public comments?: string
    ) { }
}