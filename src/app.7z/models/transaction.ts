import { Person } from './person';

export class Transaction {

    constructor(public id: number, public name: string) { }
}