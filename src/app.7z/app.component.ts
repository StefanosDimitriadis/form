import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { Http } from '@angular/http';

import { Person } from './models/person';
import { Transaction } from './models/transaction';
import { ApplicationService } from './services/application.service';
import { IMultiSelectOption } from 'angular-2-dropdown-multiselect';
import { IMultiSelectTexts } from 'angular-2-dropdown-multiselect';
import { IMultiSelectSettings } from 'angular-2-dropdown-multiselect';

@Component({
  moduleId: module.id,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit, IMultiSelectTexts, IMultiSelectSettings {

  public personsArray: Array<Person>;
  public transactionsArray: Array<Transaction>;

  optionsModel: Person[];
  mySettings: IMultiSelectSettings;
  myTexts: IMultiSelectTexts;
  myOptions: IMultiSelectOption[] = [];
  flag: boolean = false;



  form: FormGroup;

  constructor(private applicationService: ApplicationService,
    private formBuilder: FormBuilder, private http: Http) { }

  ngOnInit() {
    this.onFetchData();
    this.optionsModelInit();
    this.form = this.formBuilder.group({
      transactions: ['', Validators.required],
      representatives: [this.personsArray, Validators.required],
      representations: this.formBuilder.array([])
    });
  }

  onSubmit() {
    this.reset();

    let formAsJSON = JSON.stringify(this.form.value);

    //this.http.post("../api/representations.json").subscribe(data => data);
  }

  newRepresentation() {
    this.form.get('representations').setValue(this.form.value.transactions);
  }

  reset() {
    this.form.reset();
  }

  newTransaction() {
  }

  initRepresentations(entryObj: any) {
    return this.formBuilder.group({
      transactions: [entryObj.transactions],
      representatives: [entryObj.representatives]
    });
  }

  addRepresentation() {
    if (!this.form.invalid) {
      var entry = {
        'transactions': this.form.value.transactions,
        'representatives': this.form.value.representatives
      };
    }
    const control = <FormArray>this.form.controls['representations'];
    control.push(this.initRepresentations(entry));
  }

  removeRepresentation(i: number) {
    const control = <FormArray>this.form.controls['representations'];
    control.removeAt(i);
  }

  onFetchData() {
    Observable.forkJoin(
      this.applicationService.getPersons(),
      this.applicationService.getTransactions()
    ).subscribe(
      value => {
        this.personsArray = value[0];
        this.transactionsArray = value[1];
        this.personsArray.forEach(element => {
          if (!this.flag) {
            this.myOptions.push(element);
          }
        });
        this.flag = true;
      }
      );
  }

  optionsModelInit() {
    this.mySettings = {
      pullRight: false,
      enableSearch: false,
      checkedStyle: 'glyphicon',
      buttonClasses: 'btn btn-default',
      selectionLimit: 0,
      closeOnSelect: false,
      showCheckAll: true,
      showUncheckAll: true,
      dynamicTitleMaxItems: 2,
      maxHeight: '300px',
      displayAllSelectedText: false
    };

    this.myTexts = {
      checkAll: 'Επιλογή όλων',
      uncheckAll: 'Αφαίρεση όλων',
      checked: 'Επιλεγμένος',
      checkedPlural: 'Επιλεγμένοι',
      searchPlaceholder: 'Αναζήτηση...',
      defaultTitle: 'Επιλέξτε εκπροσώπους'
    };
  }
}