import { Injectable } from '@angular/core';
import { Person } from '../models/person';
import { Transaction } from '../models/transaction';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class ApplicationService {

    private personsUrl = "../../../src/api/persons.json";
    private transactionsUrl = "../../../src/api/transactions.json";
    
    constructor(private http: Http) { }

    getPersons(): Observable<Person[]> {
        return this.http.get(this.personsUrl)
            .map((response: Response) => {
                return response.json()
            });
    }

    getTransactions(): Observable<Transaction[]> {
        return this.http.get(this.transactionsUrl)
            .map((response: Response) => {
                return response.json()
            });
    }
}